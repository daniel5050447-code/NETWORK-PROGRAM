# 연습문제 1-1: 입/출력문

# (1) input()을 한 번 사용 + f-string 방식
a, b = map(int, input("정수 두 개를 입력하세요 (공백 구분): ").split())
print(f"{a} + {b} = {a + b}")
print(f"{a} - {b} = {a - b}")
print(f"{a} x {b} = {a * b}")
print(f"{a} / {b} = {a / b}")

# (2) input()을 두 번 사용 + format() 메소드 방식
a = int(input("첫 번째 정수: "))
b = int(input("두 번째 정수: "))
print("{} + {} = {}".format(a, b, a + b))
print("{} - {} = {}".format(a, b, a - b))
print("{} x {} = {}".format(a, b, a * b))
print("{} / {} = {}".format(a, b, a / b))
