# 연습문제 1-2: 변수 스코프

# (1) 함수 안에서 전역 변수 읽기
print("--- (1) ---")
x = 10
def test():
    print(x)        # 지역 x가 없으므로 전역 x(10)를 읽음
test()              # 10
print(x)            # 10

# (2) 함수 안에서 같은 이름의 지역 변수 생성
print("--- (2) ---")
x = 10
def test():
    x = 20          # 지역 변수 x 생성 (전역 x와 별개)
    print(x)
test()              # 20
print(x)            # 10

# (3) 중첩 함수의 스코프
print("--- (3) ---")
x = 10
def outer():
    x = 20
    def inner():
        x = 30
        print("A:", x)   # A: 30
    inner()
    print("B:", x)       # B: 20
outer()
print("C:", x)           # C: 10

# (4) UnboundLocalError
print("--- (4) ---")
# 원래 코드:
# x = 10
# def test():
#     print(x)
#     x = 20
# test()
# print(x)
#
# 오류 이유: 함수 안에 x = 20 대입문이 있으므로 파이썬은 x를 '지역 변수'로 판단한다.
# 그런데 대입 전에 print(x)로 먼저 읽으려 해서
# UnboundLocalError: local variable 'x' referenced before assignment 가 발생한다.
#
# 수정: global 선언으로 전역 변수 x를 사용하면 10, 20 순서로 출력된다.
x = 10
def test():
    global x
    print(x)        # 10
    x = 20
test()
print(x)            # 20
