# 연습문제 1-3: 수식계산
import math

# (1) a=3, b=4, c=5 일 때 1 / (1 + a/b + c)
a, b, c = 3, 4, 5
print("(1)", 1 / (1 + a / b + c))

# (2) 2차방정식 a=1, b=1, c=-6 의 두 근
a, b, c = 1, 1, -6
d = b ** 2 - 4 * a * c
x1 = (-b + math.sqrt(d)) / (2 * a)
x2 = (-b - math.sqrt(d)) / (2 * a)
print("(2)", x1, x2)

# (3) 반지름 r=5 인 원의 면적
r = 5
print("(3)", math.pi * r ** 2)

# (4) beta=2.0, g=3.2 일 때 beta * e^(-g)
beta, g = 2.0, 3.2
print("(4)", beta * math.exp(-g))

# (5) x=0, mu=1.5, rho=2.0 일 때 1/sqrt(2*pi*rho) * e^((x-mu)^2 / (2*rho^2))
x, mu, rho = 0, 1.5, 2.0
print("(5)", 1 / math.sqrt(2 * math.pi * rho) * math.exp((x - mu) ** 2 / (2 * rho ** 2)))
