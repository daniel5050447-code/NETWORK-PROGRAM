# 문제 2-2: 딕셔너리 연습

# 1. 명단 작성
students = {}
while True:
    sid = input("학번 입력 (종료: Fin!): ")
    if sid == "Fin!":
        break
    name = input("이름 입력: ")
    students[sid] = name

print(students)

# 2. 학번으로 이름 알아내기 / 3. 종료
while True:
    sid = input("찾을 학번 입력 (종료: Quit!): ")
    if sid == "Quit!":
        break
    print(students.get(sid, "not found!"))
