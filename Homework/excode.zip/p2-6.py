# 문제 2-6: 소수 찾기 - 입력받은 n이 소수인 경우에만 출력

def josa(n):
    # 숫자 읽기의 받침 유무로 '은/는' 결정 (3은, 5는 ...)
    if n % 10 == 0:                     # 10, 20, ..., 100 -> 십/백 (받침 있음)
        return '은'
    return '은' if n % 10 in (0, 1, 3, 6, 7, 8) else '는'

n = int(input("1~100 사이의 자연수를 입력하세요: "))

if n < 1 or n > 100:
    print("1에서 100 사이의 자연수를 입력하세요.")
else:
    is_prime = n >= 2                   # 1은 소수가 아님
    for d in range(2, n):
        if n % d == 0:
            is_prime = False
            break
    if is_prime:
        print(f"{n}{josa(n)} 소수입니다")
