# 문제 3-2: min_max 함수

def min_max(nums):
    lo = hi = nums[0]
    for n in nums[1:]:
        if n < lo:
            lo = n
        if n > hi:
            hi = n
    return (lo, hi)

nums = list(map(int, input("정수들을 입력하세요 (공백 구분): ").split()))
mn, mx = min_max(nums)
print(f"min: {mn}, max: {mx}")
