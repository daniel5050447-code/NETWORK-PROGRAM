# 문제 4-1: 라인번호 붙여 출력 + .sav 파일로 저장 (FileNotFoundError 처리)

while True:
    filename = input("파일명을 입력하세요 (종료: q): ")
    if filename == 'q':
        print("종료합니다.")
        break
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except FileNotFoundError:
        print(f"'{filename}' 파일이 없습니다. 다시 입력하세요.")
        continue

    # 1. 라인번호를 붙여 출력
    numbered = [f"{i} {line.rstrip()}" for i, line in enumerate(lines, 1)]
    for line in numbered:
        print(line)

    # 2. 라인번호를 붙여 ***.sav 로 저장
    savename = filename.rsplit('.', 1)[0] + '.sav'
    with open(savename, 'w', encoding='utf-8') as f:
        f.write('\n'.join(numbered) + '\n')
    print(f"'{savename}' 파일로 저장했습니다.")
    break
