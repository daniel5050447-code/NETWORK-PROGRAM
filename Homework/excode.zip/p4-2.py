# 문제 4-2: 글자수(공백 제외) / 단어수 / 라인수 출력 (FileNotFoundError 처리)

filename = input("파일명을 입력하세요: ")
try:
    with open(filename, 'r', encoding='utf-8') as f:
        text = f.read()
except FileNotFoundError:
    print(f"'{filename}' 파일을 찾을 수 없습니다.")
else:
    chars = len(''.join(text.split()))   # 공백(스페이스, 탭, 줄바꿈) 제외
    words = len(text.split())
    lines = len(text.splitlines())
    print(f"{'characters':<11}: {chars}")
    print(f"{'words':<11}: {words}")
    print(f"{'lines':<11}: {lines}")
